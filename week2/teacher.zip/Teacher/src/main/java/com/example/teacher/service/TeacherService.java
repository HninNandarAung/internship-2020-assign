package com.example.teacher.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.teacher.entity.Teacher;
import com.example.teacher.repository.TeacherRepository;

@Service
public class TeacherService {

	@Autowired
	TeacherRepository teacherRepository;
	
	

	public List<Teacher> getTeacher() {
		// TODO Auto-generated method stub
		return teacherRepository.findAll();
	}



	public Teacher addTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return teacherRepository.save(teacher);
	}
	
	public Teacher findById(long id) {
		return teacherRepository.findById(id).orElse(null);
	}
	
	public void deleteTeacher(long id) {
		teacherRepository.deleteById(id);
	}
}
