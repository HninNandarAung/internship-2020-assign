package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.student;
import com.example.demo.repository.StudentRepository;

@Service
public class StudentService{
	@Autowired
	StudentRepository studentRepository;
	
	public List<student> getStudent(){
		return studentRepository.findAll();
	}
	public student addStudent(student student) {
		return  studentRepository.save(student);
		
	}
	public student getStudentById(int id) {
		return studentRepository.findById(id).orElse(null);
		
	}
	public void deleteStudent(int id) {
		studentRepository.deleteById(id);
	}
	
	

}
