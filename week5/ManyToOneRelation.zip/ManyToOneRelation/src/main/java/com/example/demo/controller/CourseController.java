package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.course;
import com.example.demo.service.CourseService;

@RestController
public class CourseController {
	@Autowired
     CourseService courseService;

	@GetMapping(value="/course")
	public List<course> getCourse() {
		return courseService.getCourse();
	}
	@PostMapping(value="/course")
	public course addCourse(@RequestBody course course) {
		return courseService.addCourse(course);
	}
	@GetMapping(value="/course/(id)")
	public course getCoursesById(@PathVariable int id){
		return courseService.getCouresById(id);
	}
	@DeleteMapping(value="/course/(id)")
	public void deleteCourseById(@PathVariable int id){
		 courseService.deleteCourse(id);
	}
	

}
