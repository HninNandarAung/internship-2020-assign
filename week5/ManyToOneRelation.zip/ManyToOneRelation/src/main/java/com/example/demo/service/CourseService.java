package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.course;
import com.example.demo.repository.CourseRepository;

@Service
public class CourseService {
	@Autowired
	CourseRepository courseRepository;
	
	public List<course>getCourse(){
		return courseRepository.findAll();
	}
	public course addCourse(course course) {
		return courseRepository.save(course);
		
	}
	public course getCouresById(int id) {
		return courseRepository.findById(id).orElse(null);
		
	}
	public void deleteCourse(int id) {
		courseRepository.deleteById(id);
	}
	

}