package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.student;
import com.example.demo.service.StudentService;

@RestController
public class StudentController {
	@Autowired
	StudentService studentService;

	@GetMapping(value="/student")
	public List<student> getStudent() {
		return studentService.getStudent();
	}
	@PostMapping(value="/student")
	public student addStudent(@RequestBody student student) {
		return studentService.addStudent(student);
	}
	@GetMapping(value="/student/(id)")
	public student getStudentById(@PathVariable int id){
		return studentService.getStudentById(id);
	}
	@DeleteMapping(value="/student/(id)")
	public void deleteEmployeeById(@PathVariable int id){
		studentService.deleteStudent(id);
	}

}