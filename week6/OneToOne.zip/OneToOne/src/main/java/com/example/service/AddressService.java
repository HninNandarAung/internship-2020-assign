package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entity.Address;
import com.example.repository.AddressRepository;


@Service
public class AddressService {
	@Autowired
	AddressRepository addressRepository;
	
	public List<Address>getCourse(){
		return addressRepository.findAll();
	}
	public Address addAddress(Address address) {
		return addressRepository.save(address);
		
	}
	public Address getAddressById(long id) {
		return addressRepository.findById(id).orElse(null);
		
	}
	public void deleteAddress(long id) {
		addressRepository.deleteById(id);
	}
	

}