package com.example.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "address")
public class Address{
 
    @Id
    @Column(name = "id")
    private Long id;
 
    @OneToOne
    @MapsId
    private User user;
   @Column(name="Street")
   String street;
   @Column(name="Quarter")
   String quarter;
   @Column(name="Town")
   String town;
   @Column(name="State")
   String state;
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public User getUser() {
	return user;
}
public void setUser(User user) {
	this.user = user;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getQuarter() {
	return quarter;
}
public void setQuarter(String quarter) {
	this.quarter = quarter;
}
public String getTown() {
	return town;
}
public void setTown(String town) {
	this.town = town;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
   
}
